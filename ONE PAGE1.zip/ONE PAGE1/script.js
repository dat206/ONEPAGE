// DOM Elements
const navbar = document.getElementById('navbar');
const navMenu = document.getElementById('navMenu');
const hamburger = document.getElementById('hamburger');
const navLinks = document.querySelectorAll('.nav-link');
const contactForm = document.getElementById('contactForm');
const cartModal = document.getElementById('cartModal');
const cartIcon = document.querySelector('.cart-icon');
const closeModal = document.querySelector('.close');

// Shopping Cart Data
let cart = [];
let wishlist = [];

// Product Data
const products = [
    {
        id: 1,
        name: 'MacBook Pro M2 2024',
        price: 35990000,
        originalPrice: 42990000,
        image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=300&fit=crop&crop=center&auto=format',
        category: 'laptop',
        rating: 4.5,
        badge: 'Best Seller',
        specs: ['M2 Chip', '16GB RAM', '512GB SSD']
    },
    {
        id: 2,
        name: 'iPhone 15 Pro Max 256GB',
        price: 28990000,
        originalPrice: 32990000,
        image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=300&fit=crop&crop=center&auto=format',
        category: 'phone',
        rating: 5.0,
        badge: 'New',
        specs: ['A17 Pro', '256GB', 'Titanium']
    },
    {
        id: 3,
        name: 'PlayStation 5 Slim',
        price: 12990000,
        originalPrice: 15990000,
        image: 'https://images.unsplash.com/photo-1606897559973-1246e5b2b6d3?w=400&h=300&fit=crop&crop=center&auto=format',
        category: 'gaming',
        rating: 4.0,
        badge: 'Hot',
        specs: ['825GB SSD', '4K Gaming', '1 Controller']
    },
    {
        id: 4,
        name: 'AirPods Pro 2nd Gen',
        price: 5990000,
        originalPrice: 7490000,
        image: 'https://images.unsplash.com/photo-1588423771073-b8903fbb85b5?w=400&h=300&fit=crop&crop=center&auto=format',
        category: 'accessories',
        rating: 4.7,
        badge: null,
        specs: ['ANC 2x', '6H Battery', 'USB-C']
    },
    {
        id: 5,
        name: 'Dell XPS 15 Touch',
        price: 45990000,
        originalPrice: 52990000,
        image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=300&fit=crop&crop=center&auto=format',
        category: 'laptop',
        rating: 4.2,
        badge: null,
        specs: ['i7-13700H', '32GB RAM', '1TB SSD']
    },
    {
        id: 6,
        name: 'Apple Watch Series 9 GPS',
        price: 8990000,
        originalPrice: 11990000,
        image: 'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?w=400&h=300&fit=crop&crop=center&auto=format',
        category: 'accessories',
        rating: 4.6,
        badge: 'New',
        specs: ['45mm', 'GPS', 'Water Resistant']
    },
    {
        id: 7,
        name: 'Samsung Galaxy S24 Ultra',
        price: 26990000,
        originalPrice: 29990000,
        image: 'https://images.unsplash.com/photo-1592750475338-74b7bd210bcb?w=400&h=300&fit=crop&crop=center&auto=format',
        category: 'phone',
        rating: 4.8,
        badge: 'Premium',
        specs: ['Snapdragon 8 Gen 3', '256GB', 'S Pen']
    },
    {
        id: 8,
        name: 'ASUS ROG Strix G15',
        price: 31990000,
        originalPrice: 36990000,
        image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400&h=300&fit=crop&crop=center&auto=format',
        category: 'gaming',
        rating: 4.1,
        badge: 'Gaming',
        specs: ['Ryzen 7', 'RTX 4060', '16GB RAM']
    }
];

// Mobile Menu Toggle
hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        navMenu.classList.remove('active');
    });
});

// Navbar scroll effect
window.addEventListener('scroll', () => {
    if (window.scrollY > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Active navigation link based on scroll position
function updateActiveNavLink() {
    const sections = document.querySelectorAll('section');
    const scrollPos = window.scrollY + 100;

    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        const sectionId = section.getAttribute('id');
        
        if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });
        }
    });
}

window.addEventListener('scroll', updateActiveNavLink);

// Smooth scrolling for navigation links
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 70;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Product Category Filter
const categoryBtns = document.querySelectorAll('.category-btn');
const productCards = document.querySelectorAll('.product-card');

categoryBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const category = btn.dataset.category;
        
        // Update active button
        categoryBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // Filter products
        productCards.forEach(card => {
            if (category === 'all' || card.dataset.category === category) {
                card.style.display = 'block';
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 100);
            } else {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        });
    });
});

// Shopping Cart Functions
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }
    
    updateCartUI();
    showNotification(`${product.name} đã được thêm vào giỏ hàng!`, 'success');
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartUI();
}

function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (!item) return;
    
    item.quantity += change;
    
    if (item.quantity <= 0) {
        removeFromCart(productId);
    } else {
        updateCartUI();
    }
}

function updateCartUI() {
    const cartCount = document.querySelector('.cart-count');
    const cartItems = document.querySelector('.cart-items');
    const totalPrice = document.querySelector('.total-price');
    
    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    
    // Update cart items
    if (cart.length === 0) {
        cartItems.innerHTML = '<p class="empty-cart">Giỏ hàng trống</p>';
        totalPrice.textContent = '0₫';
        return;
    }
    
    cartItems.innerHTML = cart.map(item => `
        <div class="cart-item">
            <img src="${item.image}" alt="${item.name}">
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${formatPrice(item.price)}</div>
            </div>
            <div class="cart-item-quantity">
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                <span>${item.quantity}</span>
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
            </div>
        </div>
    `).join('');
    
    // Update total price
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    totalPrice.textContent = formatPrice(total);
}

function formatPrice(price) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

// Cart Modal
cartIcon.addEventListener('click', (e) => {
    e.preventDefault();
    cartModal.style.display = 'block';
    updateCartUI();
});

closeModal.addEventListener('click', () => {
    cartModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === cartModal) {
        cartModal.style.display = 'none';
    }
});

// Add to Cart Buttons
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart')) {
        const productCard = e.target.closest('.product-card');
        const productId = parseInt(productCard.dataset.category === 'laptop' ? 
            (productCard.querySelector('.product-name').textContent.includes('MacBook') ? 1 : 5) :
            productCard.querySelector('.product-name').textContent.includes('iPhone') ? 2 :
            productCard.querySelector('.product-name').textContent.includes('PlayStation') ? 3 :
            productCard.querySelector('.product-name').textContent.includes('AirPods') ? 4 : 6);
        
        addToCart(productId);
    }
});

// Wishlist Toggle
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('wishlist') || e.target.closest('.wishlist')) {
        const btn = e.target.classList.contains('wishlist') ? e.target : e.target.closest('.wishlist');
        const productCard = btn.closest('.product-card');
        const productId = parseInt(productCard.dataset.category === 'laptop' ? 
            (productCard.querySelector('.product-name').textContent.includes('MacBook') ? 1 : 5) :
            productCard.querySelector('.product-name').textContent.includes('iPhone') ? 2 :
            productCard.querySelector('.product-name').textContent.includes('PlayStation') ? 3 :
            productCard.querySelector('.product-name').textContent.includes('AirPods') ? 4 : 6);
        
        const index = wishlist.indexOf(productId);
        if (index > -1) {
            wishlist.splice(index, 1);
            btn.classList.remove('active');
            btn.innerHTML = '<i class="far fa-heart"></i>';
            showNotification('Đã xóa khỏi danh sách yêu thích', 'info');
        } else {
            wishlist.push(productId);
            btn.classList.add('active');
            btn.innerHTML = '<i class="fas fa-heart"></i>';
            showNotification('Đã thêm vào danh sách yêu thích!', 'success');
        }
    }
});

// Testimonials Slider
let currentSlide = 0;
const testimonialCards = document.querySelectorAll('.testimonial-card');
const dots = document.querySelectorAll('.dot');

function showSlide(index) {
    testimonialCards.forEach(card => card.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));
    
    testimonialCards[index].classList.add('active');
    dots[index].classList.add('active');
    currentSlide = index;
}

function nextSlide() {
    currentSlide = (currentSlide + 1) % testimonialCards.length;
    showSlide(currentSlide);
}

function prevSlide() {
    currentSlide = (currentSlide - 1 + testimonialCards.length) % testimonialCards.length;
    showSlide(currentSlide);
}

// Auto-play testimonials
setInterval(nextSlide, 5000);

// Dot click handlers
dots.forEach((dot, index) => {
    dot.addEventListener('click', () => showSlide(index));
});

// Quick View
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('quick-view')) {
        const productCard = e.target.closest('.product-card');
        const productName = productCard.querySelector('.product-name').textContent;
        showNotification(`Xem nhanh: ${productName}`, 'info');
    }
});

// Deal Timer Countdown
function updateDealTimer() {
    const timerElements = document.querySelectorAll('.timer');
    
    timerElements.forEach(timer => {
        // Set end time to 24 hours from now
        const endTime = new Date();
        endTime.setHours(23, 59, 59);
        
        const now = new Date();
        const timeLeft = endTime - now;
        
        if (timeLeft > 0) {
            const hours = Math.floor(timeLeft / (1000 * 60 * 60));
            const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
            
            timer.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        } else {
            timer.textContent = 'Đã kết thúc';
        }
    });
}

// Update timer every second
setInterval(updateDealTimer, 1000);
updateDealTimer();

// Contact form handling
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(contactForm);
        const formObject = {};
        formData.forEach((value, key) => {
            formObject[key] = value;
        });
        
        // Simple form validation
        const name = formObject.name.trim();
        const email = formObject.email.trim();
        const subject = formObject.subject;
        const message = formObject.message.trim();
        
        if (!name || !email || !subject || !message) {
            showNotification('Vui lòng điền đầy đủ thông tin', 'error');
            return;
        }
        
        if (!isValidEmail(email)) {
            showNotification('Vui lòng nhập email hợp lệ', 'error');
            return;
        }
        
        // Simulate form submission
        const submitButton = contactForm.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.textContent = 'Đang gửi...';
        submitButton.disabled = true;
        
        setTimeout(() => {
            showNotification('Tin nhắn đã được gửi! Chúng tôi sẽ liên hệ sớm.', 'success');
            contactForm.reset();
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        }, 2000);
    });
}

// Email validation
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Notification system
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 10px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    
    // Set background color based on type
    switch(type) {
        case 'success':
            notification.style.background = '#10B981';
            break;
        case 'error':
            notification.style.background = '#EF4444';
            break;
        default:
            notification.style.background = '#2563EB';
    }
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 4 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 4000);
}

// Parallax effect for hero section
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero');
    const heroContent = document.querySelector('.hero-content');
    
    if (hero && heroContent) {
        hero.style.transform = `translateY(${scrolled * 0.5}px)`;
        heroContent.style.transform = `translateY(${scrolled * 0.3}px)`;
        heroContent.style.opacity = 1 - scrolled / 600;
    }
});

// Scroll animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, observerOptions);

// Observe elements for scroll animations
document.addEventListener('DOMContentLoaded', () => {
    // Add animation classes to elements
    const animateElements = document.querySelectorAll('.timeline-item, .feature-card, .product-card, .deal-card, .stat-item');
    
    animateElements.forEach((el, index) => {
        // Add different animation classes based on element type
        if (el.classList.contains('timeline-item')) {
            el.classList.add('slide-in-left');
        } else if (el.classList.contains('feature-card')) {
            el.classList.add('fade-in');
        } else if (el.classList.contains('product-card')) {
            el.classList.add('scale-in');
        } else if (el.classList.contains('deal-card')) {
            el.classList.add('slide-in-right');
        } else if (el.classList.contains('stat-item')) {
            el.classList.add('fade-in');
        }
        
        // Add stagger effect
        el.style.transitionDelay = `${index * 0.1}s`;
        
        observer.observe(el);
    });

    // Observe sections
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        observer.observe(section);
    });
});

// Counter animation for statistics
function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const increment = target / (duration / 16);
    
    const updateCounter = () => {
        start += increment;
        if (start < target) {
            element.textContent = Math.ceil(start).toLocaleString() + '+';
            requestAnimationFrame(updateCounter);
        } else {
            element.textContent = target.toLocaleString() + '+';
        }
    };
    
    updateCounter();
}

// Observe stat numbers for counter animation
const statNumbers = document.querySelectorAll('.stat-number');
const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting && !entry.target.classList.contains('counted')) {
            const text = entry.target.textContent;
            const match = text.match(/[\d,]+/);
            if (match) {
                const target = parseInt(match[0].replace(/,/g, ''));
                if (!isNaN(target)) {
                    animateCounter(entry.target, target);
                    entry.target.classList.add('counted');
                }
            }
        }
    });
}, { threshold: 0.5 });

statNumbers.forEach(stat => {
    counterObserver.observe(stat);
});

// Performance optimization - Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Debounced scroll handlers
const debouncedScroll = debounce(() => {
    updateActiveNavLink();
}, 10);

window.addEventListener('scroll', debouncedScroll);

// Console Easter egg
console.log('%c � Welcome to TechZone!', 'color: #2563EB; font-size: 16px; font-weight: bold;');
console.log('%c Cửa hàng công nghệ hàng đầu Việt Nam', 'color: #F59E0B; font-size: 14px;');
console.log('%c Khám phá công nghệ trong tầm tay!', 'color: #10B981; font-size: 14px;');

// Hero Section Advanced Animations
function initHeroAnimations() {
    // Animate hero badge
    const heroBadge = document.querySelector('.hero-badge');
    if (heroBadge) {
        setTimeout(() => {
            heroBadge.style.opacity = '1';
            heroBadge.style.transform = 'translateY(0)';
        }, 300);
    }
    
    // Animate hero title with typewriter effect
    const heroTitle = document.querySelector('.hero-title');
    if (heroTitle) {
        const text = heroTitle.textContent;
        heroTitle.textContent = '';
        heroTitle.style.opacity = '1';
        
        let charIndex = 0;
        function typeWriter() {
            if (charIndex < text.length) {
                heroTitle.textContent += text.charAt(charIndex);
                charIndex++;
                setTimeout(typeWriter, 50);
            }
        }
        
        setTimeout(typeWriter, 600);
    }
    
    // Animate hero subtitle and description
    const heroSubtitle = document.querySelector('.hero-subtitle');
    const heroDescription = document.querySelector('.hero-description');
    
    if (heroSubtitle) {
        setTimeout(() => {
            heroSubtitle.style.opacity = '1';
            heroSubtitle.style.transform = 'translateY(0)';
        }, 1500);
    }
    
    if (heroDescription) {
        setTimeout(() => {
            heroDescription.style.opacity = '1';
            heroDescription.style.transform = 'translateY(0)';
        }, 1800);
    }
    
    // Animate hero buttons
    const heroButtons = document.querySelector('.hero-buttons');
    if (heroButtons) {
        setTimeout(() => {
            heroButtons.style.opacity = '1';
            heroButtons.style.transform = 'translateY(0)';
        }, 2100);
    }
    
    // Animate stats with counter
    const statItems = document.querySelectorAll('.stat-item');
    const statNumbers = document.querySelectorAll('.stat-number[data-count]');
    
    statItems.forEach((item, index) => {
        setTimeout(() => {
            item.style.opacity = '1';
            item.style.transform = 'translateY(0)';
        }, 2400 + (index * 200));
    });
    
    // Animate counters
    statNumbers.forEach(stat => {
        const target = parseInt(stat.dataset.count);
        const duration = 2000;
        const increment = target / (duration / 16);
        let current = 0;
        
        const updateCounter = () => {
            current += increment;
            if (current < target) {
                stat.textContent = Math.ceil(current).toLocaleString();
                requestAnimationFrame(updateCounter);
            } else {
                stat.textContent = target.toLocaleString() + '+';
            }
        };
        
        // Start counter when stat item is visible
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    observer.unobserve(entry.target);
                }
            });
        });
        
        observer.observe(stat);
    });
    
    // Animate hero 3D showcase
    const heroShowcase = document.querySelector('.hero-product-showcase');
    if (heroShowcase) {
        setTimeout(() => {
            heroShowcase.style.opacity = '1';
            heroShowcase.style.transform = 'scale(1)';
        }, 1000);
    }
    
    // Add parallax effect to hero background
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const heroBackground = document.querySelector('.hero-background');
        const heroGradient = document.querySelector('.hero-gradient');
        const heroContent = document.querySelector('.hero-content');
        
        if (heroBackground && heroGradient && heroContent) {
            heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`;
            heroGradient.style.transform = `translateY(${scrolled * 0.3}px)`;
            heroContent.style.transform = `translateY(${scrolled * 0.1}px)`;
            heroContent.style.opacity = 1 - scrolled / 800;
        }
    });
    
    // Add floating animation to elements
    const floatElements = document.querySelectorAll('.float-element');
    floatElements.forEach((element, index) => {
        element.style.animationDelay = `${index * 0.5}s`;
    });
}

// Enhanced Visual Effects
function addVisualEffects() {
    // Add floating particles to sections
    const sections = document.querySelectorAll('section');
    sections.forEach(section => {
        if (!section.classList.contains('hero')) {
            const particles = document.createElement('div');
            particles.className = 'section-particles';
            particles.style.cssText = `
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                pointer-events: none;
                overflow: hidden;
            `;
            
            // Add floating particles
            for (let i = 0; i < 5; i++) {
                const particle = document.createElement('div');
                particle.style.cssText = `
                    position: absolute;
                    width: ${Math.random() * 4 + 2}px;
                    height: ${Math.random() * 4 + 2}px;
                    background: rgba(37, 99, 235, ${Math.random() * 0.3 + 0.1});
                    border-radius: 50%;
                    top: ${Math.random() * 100}%;
                    left: ${Math.random() * 100}%;
                    animation: floatParticle ${Math.random() * 10 + 5}s infinite ease-in-out;
                    animation-delay: ${Math.random() * 5}s;
                `;
                particles.appendChild(particle);
            }
            
            section.appendChild(particles);
        }
    });
    
    // Add hover sound effect simulation (visual feedback)
    const buttons = document.querySelectorAll('.btn, .add-to-cart, .wishlist, .quick-view');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            button.style.transform = 'scale(1.05)';
            setTimeout(() => {
                button.style.transform = '';
            }, 200);
        });
    });
    
    // Add ripple effect to all clickable elements
    const clickables = document.querySelectorAll('.btn, .add-to-cart, .wishlist, .quick-view, .category-btn');
    clickables.forEach(element => {
        element.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                left: ${x}px;
                top: ${y}px;
                pointer-events: none;
                animation: rippleEffect 0.6s ease-out;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });
    
    // Add parallax effect to product cards
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width;
            const y = (e.clientY - rect.top) / rect.height;
            
            const centerX = 0.5;
            const centerY = 0.5;
            const deltaX = (x - centerX) * 10;
            const deltaY = (y - centerY) * 10;
            
            card.style.transform = `translateY(-15px) scale(1.03) rotateY(${deltaX}deg) rotateX(${-deltaY}deg)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = '';
        });
    });
    
    // Add CSS for new animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes floatParticle {
            0%, 100% { transform: translateY(0px) translateX(0px); }
            25% { transform: translateY(-20px) translateX(10px); }
            50% { transform: translateY(-10px) translateX(-10px); }
            75% { transform: translateY(-30px) translateX(5px); }
        }
        
        @keyframes rippleEffect {
            0% {
                transform: scale(0);
                opacity: 1;
            }
            100% {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        .section-particles {
            z-index: 0;
        }
        
        .product-card {
            transform-style: preserve-3d;
            perspective: 1000px;
        }
        
        .product-image img {
            transition: transform 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .product-card:hover .product-image img {
            transform: scale(1.15) rotateX(5deg);
        }
    `;
    document.head.appendChild(style);
}

// Enhanced product interactions
function enhanceProductInteractions() {
    const productCards = document.querySelectorAll('.product-card');
    
    productCards.forEach(card => {
        // Add loading state simulation
        const addToCartBtn = card.querySelector('.add-to-cart');
        if (addToCartBtn) {
            addToCartBtn.addEventListener('click', function() {
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang thêm...';
                this.disabled = true;
                
                setTimeout(() => {
                    this.innerHTML = '<i class="fas fa-check"></i> Đã thêm!';
                    this.style.background = 'linear-gradient(135deg, #10B981, #059669)';
                    
                    setTimeout(() => {
                        this.innerHTML = originalText;
                        this.style.background = '';
                        this.disabled = false;
                    }, 2000);
                }, 1000);
            });
        }
        
        // Add wishlist animation
        const wishlistBtn = card.querySelector('.wishlist');
        if (wishlistBtn) {
            wishlistBtn.addEventListener('click', function() {
                if (this.classList.contains('active')) {
                    // Remove from wishlist with animation
                    this.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        this.classList.remove('active');
                        this.innerHTML = '<i class="far fa-heart"></i>';
                        this.style.transform = '';
                    }, 200);
                } else {
                    // Add to wishlist with animation
                    this.classList.add('active');
                    this.innerHTML = '<i class="fas fa-heart"></i>';
                    this.style.transform = 'scale(1.3)';
                    setTimeout(() => {
                        this.style.transform = '';
                    }, 200);
                }
            });
        }
        
        // Add quick view modal
        const quickViewBtn = card.querySelector('.quick-view');
        if (quickViewBtn) {
            quickViewBtn.addEventListener('click', function() {
                const productName = card.querySelector('.product-name').textContent;
                const productImage = card.querySelector('.product-image img').src;
                const productPrice = card.querySelector('.current-price').textContent;
                
                // Create modal
                const modal = document.createElement('div');
                modal.className = 'quick-view-modal';
                modal.style.cssText = `
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0,0,0,0.8);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    z-index: 10000;
                    opacity: 0;
                    transition: opacity 0.3s ease;
                `;
                
                modal.innerHTML = `
                    <div class="modal-content" style="
                        background: white;
                        border-radius: 20px;
                        padding: 2rem;
                        max-width: 600px;
                        width: 90%;
                        max-height: 80vh;
                        overflow-y: auto;
                        transform: scale(0.9);
                        transition: transform 0.3s ease;
                    ">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                            <h2 style="color: var(--text-dark); font-size: 1.5rem; font-weight: 800;">${productName}</h2>
                            <button class="close-modal" style="
                                background: none;
                                border: none;
                                font-size: 1.5rem;
                                cursor: pointer;
                                color: var(--text-light);
                                width: 40px;
                                height: 40px;
                                border-radius: 50%;
                                display: flex;
                                align-items: center;
                                justify-content: center;
                                transition: all 0.3s ease;
                            ">✕</button>
                        </div>
                        <img src="${productImage}" style="width: 100%; height: 300px; object-fit: cover; border-radius: 15px; margin-bottom: 1.5rem;">
                        <div style="font-size: 2rem; font-weight: 900; color: var(--primary-color); margin-bottom: 1rem;">${productPrice}</div>
                        <p style="color: var(--text-light); margin-bottom: 2rem;">Sản phẩm chất lượng cao với bảo hành chính hãng. Giao hàng nhanh chóng toàn quốc.</p>
                        <button class="add-to-cart-modal" style="
                            width: 100%;
                            padding: 1rem;
                            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
                            color: white;
                            border: none;
                            border-radius: 10px;
                            font-weight: 700;
                            font-size: 1.1rem;
                            cursor: pointer;
                            transition: all 0.3s ease;
                        ">Thêm vào giỏ hàng</button>
                    </div>
                `;
                
                document.body.appendChild(modal);
                
                // Animate in
                setTimeout(() => {
                    modal.style.opacity = '1';
                    modal.querySelector('.modal-content').style.transform = 'scale(1)';
                }, 10);
                
                // Close functions
                const closeModal = () => {
                    modal.style.opacity = '0';
                    modal.querySelector('.modal-content').style.transform = 'scale(0.9)';
                    setTimeout(() => {
                        if (modal.parentNode) {
                            modal.parentNode.removeChild(modal);
                        }
                    }, 300);
                };
                
                // Close on background click
                modal.addEventListener('click', (e) => {
                    if (e.target === modal) {
                        closeModal();
                    }
                });
                
                // Close on X button click
                const closeBtn = modal.querySelector('.close-modal');
                if (closeBtn) {
                    closeBtn.addEventListener('click', closeModal);
                }
                
                // Close on ESC key
                const escHandler = (e) => {
                    if (e.key === 'Escape') {
                        closeModal();
                        document.removeEventListener('keydown', escHandler);
                    }
                };
                document.addEventListener('keydown', escHandler);
                
                // Add hover effects
                closeBtn.addEventListener('mouseenter', () => {
                    closeBtn.style.background = 'rgba(0,0,0,0.1)';
                });
                closeBtn.addEventListener('mouseleave', () => {
                    closeBtn.style.background = 'none';
                });
                
                // Mouse follow effect for close button
                closeBtn.addEventListener('mousemove', (e) => {
                    const rect = closeBtn.getBoundingClientRect();
                    const centerX = rect.left + rect.width / 2;
                    const centerY = rect.top + rect.height / 2;
                    const deltaX = (e.clientX - centerX) * 0.1;
                    const deltaY = (e.clientY - centerY) * 0.1;
                    
                    closeBtn.style.transform = `translate(${deltaX}px, ${deltaY}px) scale(1.1)`;
                });
                
                closeBtn.addEventListener('mouseleave', () => {
                    closeBtn.style.transform = 'translate(0, 0) scale(1)';
                });
                
                const addToCartBtn = modal.querySelector('.add-to-cart-modal');
                addToCartBtn.addEventListener('mouseenter', () => {
                    addToCartBtn.style.transform = 'translateY(-2px)';
                    addToCartBtn.style.boxShadow = '0 8px 25px rgba(37, 99, 235, 0.4)';
                });
                addToCartBtn.addEventListener('mouseleave', () => {
                    addToCartBtn.style.transform = 'translateY(0)';
                    addToCartBtn.style.boxShadow = 'none';
                });
            });
        }
    });
}

// Initialize enhanced effects
document.addEventListener('DOMContentLoaded', () => {
    // Initialize hero animations
    initHeroAnimations();
    
    // Add visual effects
    addVisualEffects();
    
    // Enhance product interactions
    enhanceProductInteractions();
    
    // Initialize cart
    updateCartUI();
    
    // Add stagger animations to grids
    const grids = document.querySelectorAll('.products-grid, .services-grid, .features-grid, .blog-grid');
    grids.forEach(grid => {
        grid.classList.add('stagger-fade-in');
        const rect = grid.getBoundingClientRect();
        if (rect.top < window.innerHeight) {
            grid.classList.add('visible');
        } else {
            observer.observe(grid);
        }
    });
    
    // Add initial styles for animations
    const animatedElements = document.querySelectorAll('.hero-badge, .hero-title, .hero-subtitle, .hero-description, .hero-buttons, .stat-item, .hero-product-showcase');
    animatedElements.forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(30px)';
        element.style.transition = 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)';
    });
});

// Export functions for potential use in other scripts
window.TechZone = {
    addToCart,
    removeFromCart,
    updateQuantity,
    showNotification,
    formatPrice
};
