# TechZone - Cửa hàng Công nghệ Hiện đại

Website thương mại điện tử chuyên bán đồ công nghệ tham gia cuộc thi "ONE PAGE – ONE STORY 2026"

## 📋 Mô tả dự án

Đây là một website thương mại điện tử chuyên về sản phẩm công nghệ được xây dựng theo concept **"TechZone - Công nghệ trong tầm tay"**. Website thể hiện một cửa hàng công nghệ hiện đại với đầy đủ tính năng mua sắm, từ việc trưng bày sản phẩm đến giỏ hàng và thanh toán.

## 🎯 Chủ đề cuộc thi

- **Nhóm chủ đề**: Sản phẩm / Dịch vụ (Product Landing Page)
- **Concept**: TechZone - Cửa hàng công nghệ hiện đại
- **Mục tiêu**: Landing page giới thiệu cửa hàng bán đồ công nghệ

## ✨ Tính năng nổi bật

### 🛒 Tính năng Thương mại điện tử
- **Product Showcase**: Trưng bày sản phẩm với hình ảnh, giá, đánh giá
- **Category Filter**: Lọc sản phẩm theo danh mục (Laptop, Điện thoại, Phụ kiện, Gaming)
- **Shopping Cart**: Giỏ hàng động với thêm/xóa/cập nhật số lượng
- **Wishlist**: Danh sách sản phẩm yêu thích
- **Quick View**: Xem nhanh thông tin sản phẩm
- **Deal Timer**: Đếm ngược khuyến mãi

### 🎨 Thiết kế & UI/UX
- **Modern E-commerce Design**: Thiết kế hiện đại chuyên nghiệp cho bán hàng
- **Visual Hierarchy**: Phân cấp thông tin sản phẩm rõ ràng
- **Responsive**: Hoạt động mượt mà trên mọi thiết bị
- **Animations**: Hiệu ứng hover, transitions, scroll animations
- **Call-to-Action**: Nút kêu gọi hành động nổi bật

### 🛠️ Kỹ thuật đã sử dụng

#### Frontend
- **HTML5**: Semantic markup, accessibility
- **CSS3**: Flexbox, Grid, Custom Properties, Animations
- **JavaScript**: ES6+, DOM manipulation, Intersection Observer

#### Features
- **Navigation**: Sticky navbar với smooth scroll
- **Mobile Menu**: Hamburger menu responsive
- **Scroll Animations**: Hiệu ứng khi scroll sử dụng Intersection Observer
- **Cart System**: Quản lý giỏ hàng hoàn chỉnh
- **Form Validation**: Contact form với validation
- **Typography**: Font Inter từ Google Fonts
- **Icons**: Font Awesome icons

## 📁 Cấu trúc thư mục

```
ONE PAGE1/
├── index.html          # Main HTML file
├── styles.css          # Stylesheet
├── script.js           # JavaScript functionality
└── README.md           # Project documentation
```

## 🚀 Cách chạy dự án

1. **Mở file index.html trong trình duyệt**
   ```bash
   # Double click on index.html hoặc
   # Mở với XAMPP/WAMP nếu có
   ```

2. **Hoặc chạy với local server**
   ```bash
   # Sử dụng Python
   python -m http.server 8000
   
   # Sử dụng Node.js
   npx serve .
   
   # Sử dụng PHP (XAMPP)
   # Đặt thư mục trong htdocs và truy cập localhost/ONE%20PAGE1/
   ```

## 📱 Responsive Breakpoints

- **Desktop**: 1200px+
- **Tablet**: 768px - 1199px
- **Mobile**: < 768px

## 🎯 Các sections chính

### 1. Hero Section
- Giới thiệu TechZone với slogan ấn tượng
- Thống kê cửa hàng (khách hàng, sản phẩm, đánh giá)
- Call-to-action buttons dẫn đến sản phẩm và khuyến mãi
- Product showcase với badge "Hot Deal"

### 2. Products Section
- Danh sách sản phẩm nổi bật với 6 sản phẩm mẫu
- Category filter (Tất cả, Laptop, Điện thoại, Phụ kiện, Gaming)
- Product cards với hình ảnh, giá, rating, nút thêm vào giỏ
- Quick view và wishlist functionality

### 3. Features Section
- 4 lợi ích khi mua hàng tại TechZone
- Icons và descriptions cho shipping, bảo hành, chất lượng, hỗ trợ

### 4. Deals Section
- 3 deals khuyến mãi với countdown timer
- Featured deal nổi bật với grid layout lớn hơn
- Pricing comparisons và badges giảm giá

### 5. About Section
- Timeline phát triển của TechZone từ 2020-2024
- Thống kê kinh doanh với animated counters
- Storytelling về quá trình phát triển

### 6. Contact Section
- Thông tin liên hệ đầy đủ (địa chỉ, hotline, email, giờ làm việc)
- Contact form với validation và multiple subject types
- Social media links

### 7. Footer
- Company information và payment methods
- Links to products, support, và company info
- Professional footer layout

## ⚡ Tối ưu hiệu suất

- **Lazy Loading**: Images được load khi cần
- **Debounced Scroll**: Tối ưu scroll events
- **CSS Animations**: Sử dụng transform và opacity
- **Font Optimization**: Google Fonts với display=swap
- **Minified Assets**: Code được tối ưu

## 🔧 Tùy chỉnh

### Thay đổi thông tin cửa hàng
1. Mở file `index.html`
2. Tìm và thay thế:
   - `TechZone` → Tên cửa hàng của bạn
   - `support@techzone.vn` → Email của bạn
   - `1900 1234` → Hotline của bạn
   - `123 Nguyễn Huệ, Q.1, TP.HCM` → Địa chỉ của bạn

### Thay đổi sản phẩm
Trong `script.js`, chỉnh sửa mảng `products`:
```javascript
const products = [
    {
        id: 1,
        name: 'Tên sản phẩm',
        price: 1000000,
        originalPrice: 1500000,
        image: 'url-to-image',
        category: 'laptop',
        rating: 4.5,
        badge: 'New' // hoặc null
    }
];
```

### Thay đổi màu sắc
Mở file `styles.css` và chỉnh sửa CSS variables:
```css
:root {
    --primary-color: #2563EB;    /* Màu chính */
    --secondary-color: #F59E0B;  /* Màu phụ */
    --accent-color: #10B981;     /* Màu accent */
    --danger-color: #EF4444;     /* Màu danger */
    /* ... */
}
```

## 📊 Tiêu chí chấm điểm cuộc thi

### ✅ Đáp ứng yêu cầu

| Tiêu chí | Điểm | Ghi chú |
|----------|------|---------|
| **Ý tưởng & thông điệp (20%)** | 🎯 | Concept "TechZone" rõ ràng, story mạch lạc về cửa hàng công nghệ |
| **Bám sát chủ đề (15%)** | ✅ | Nhóm chủ đề Sản phẩm/Dịch vụ - Landing page bán đồ công nghệ |
| **Bố cục & UI/UX (25%)** | 🎨 | E-commerce layout, visual hierarchy tốt, CTA rõ ràng |
| **Typography (10%)** | ✅ | Font Inter, sizing, spacing hợp lý cho thương mại |
| **Kỹ thuật & lập trình (20%)** | 🚀 | HTML5, CSS3, JS, Responsive, Cart system, Animations |
| **Tính ứng dụng (5%)** | 💼 | Website có thể sử dụng thật, CTA mua hàng rõ ràng |

## 🌟 Điểm nổi bật

1. **E-commerce Complete**: Đầy đủ tính năng mua sắm từ A-Z
2. **Interactive Shopping Experience**: Cart, wishlist, filters, quick view
3. **Professional Design**: Design hiện đại phù hợp cửa hàng công nghệ
4. **Responsive**: Tối ưu mọi thiết bị cho mua sắm
5. **Performance**: Code được tối ưu tốt
6. **User Experience**: Flow từ xem sản phẩm đến thanh toán mượt mà

## 📝 Ghi chú phát triển

- Không sử dụng template có sẵn
- Code được viết từ đầu theo concept thương mại điện tử
- Sử dụng thư viện hỗ trợ (Font Awesome, Google Fonts)
- Có thể sử dụng AI để hỗ trợ coding
- Follow best practices và web standards

## 🛠️ Tính năng kỹ thuật

### Shopping Cart System
- Add/remove products
- Quantity management
- Price calculation (VND format)
- Local storage (có thể mở rộng)

### Product Management
- Category filtering
- Search functionality (có thể mở rộng)
- Product comparison (có thể mở rộng)
- Quick view modal

### User Experience
- Smooth scroll navigation
- Loading states
- Error handling
- Success notifications
- Form validation

## 🤝 Contributing

Nếu muốn cải thiện dự án:
1. Fork dự án
2. Tạo branch feature
3. Commit changes
4. Push và tạo Pull Request

## 📄 License

Dự án này được tạo ra cho mục đích học tập và tham gia cuộc thi.

---

**Built with ❤️ using HTML5, CSS3 & JavaScript**

*Good luck with the competition!* 🛒🚀
